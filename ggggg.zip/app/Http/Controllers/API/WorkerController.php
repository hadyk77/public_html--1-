<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterWorkerRequest;
use App\Models\TypeUser;
use Illuminate\Http\Request;
use App\Models\Worker;
use App\Models\WorkerSallary;
use Validator;
class WorkerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $worker = Worker::where('user_id',auth()->user()->id)->get();
        return response()->json([
            'success'   => true,
            'msg'=>'  ',
            'data'=> $worker
        ]);
    }
    public function get($project_id)
    {
        $worker = Worker::where('user_id',auth()->user()->id)
                        ->where('project_id',$project_id)
                        ->get();
        return response()->json([
            'success'   => true,
            'msg'=>'',
            'data'=> $worker
        ]);
    }


    public function store(RegisterWorkerRequest $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required|string',
            'mobile' => 'required|unique:workers,mobile',
            'sallary'=>'required',
            'person_id'=> 'required|unique:workers,person_id',
            'password' =>'required|min:8'
        ]);
        if($validator->fails()){
            return response()->json($validator->errors()->toJson(),400 );
        }
        TypeUser::create([
            'mobile' => $request->mobile,
            'type'=> 3
        ]);
        $worker=Worker::create(array_merge(
            $validator->validate(),
           [ 'project_id'=>$request->project_id],
            ['user_id' => auth()->user()->id ],
            ['password'=>bcrypt($request->password)]
        ));
        return response()->json([
            'success'   => true,
            'msg'=>'تم التسجيل بنجاح',
            'data'=> $worker
        ],201);
    }

/**
     * Show the form for editing the specified resource.
     */


    public function update(Request $request, string $id)
    {
        $worker = Worker::findOrFail($id);
        $worker->update([
            'project_id'=>$request->project_id,
            'name' => $request->name,
            'mobile' => $request->mobile,
            'sallary'=>$request->sallary,
            'person_id'=> $request->person_id,
        ]);
        return response()->json([
            'success'   => true,
            'msg'=>'تم التسجيل بنجاح',
            'data'=> $worker
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $worker = Worker::findOrFail($id);
        $worker->delete();
        return response()->json([
            'success'   => true,
            'msg'=>'تم التسجيل بنجاح',
            'data'=> $worker
        ]);
    }
}
