<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterUserRequest;
use App\Models\TypeUser;
use Illuminate\Http\Request;
use http\Env\Response;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use App\Http\Traits\GeneralTrait;
use Validator;
use Auth;
use Mockery\Matcher\Type;

class AuthController extends Controller
{
    public function _construct(){
        $this->middleware('auth:api',['except'=>['login','register']]);
    }

    public function login()
    {
        $credentials = request(['email', 'password']);
        if (! $token = auth()->attempt($credentials)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        return $this->respondWithToken($token);
    }


    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }


    public function register(RegisterUserRequest $request)
    {
        $validator = Validator::make($request->all(),[
            'mobile' => 'required',
            'password' => 'required',
            'name'=>'required',
            'person_id'=>'required',
            'address'=> 'required',
        ]);

        if($validator->fails()){
            return response()->json($validator->errors()->toJson(),400 );
        }

        $user=User::create(array_merge(
            $request->all(),
            ['password'=>bcrypt($request->password)]
        ));
            TypeUser::create([
            'mobile' => $request->mobile,
            'type'=> 2
        ]);
        return response()->json(['success' => true,
            'message'=>'تم التسجيل بنجاح',
            'user'=>$user,
        ],'تم تسجيل المشرف بنجاح');
    }



    public function updateuser(Request $request,$id)
    {
        $validator = Validator::make($request->all(),[
            'name'=>'required',
            'mobile'=>'required',
            'address'=>'required',
            'person_id'=>'required',
            'password'=>'required|min:8', //confirmed
            ]);

        if($validator->fails()){
            return response()->json($validator->errors()->toJson(),400 );
        }

        $user = User::findOrFail($id);

        $mobile = User::findOrFail($id)->value('mobile');
        $type_user =TypeUser::where('mobile',$mobile)->value('id');
        $type = TypeUser::findOrFail($type_user);


       $type ->update([
        'mobile' => $request->mobile,
        'type'=> 2
    ]);
       $user->update(array_merge(
                $validator->validate(),
                ['password'=>bcrypt($request->password)]
            ));

        return response()->json([
            'message'=>'User Successfully registered',
            'user'=>$user,
        ],201);
    }




   /* public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string|min:8',
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }
        if (!$token = auth()->attempt($validator->validated())) {
            return response()->json(['error'=>'Unauthorized'],401);
        }
        return $this->createNewToken($token);
    }
    public function createNewToken($token)
    {
        return response()->json([
            'access_token' =>$token,
            'token_type'=>'bearer',
            'expires_in'=>auth()->factory()->getTTL()*60,
            'user'=>auth()->user(),
        ]);

    }
    public function profile(){
        return response()->json(auth()->user());
    }
    public function logout(){
        auth()->logout();
        return response()->json(['message' =>'User Logged out']);
    }
*/
}

