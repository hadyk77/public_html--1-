<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterWorkerRequest;
use Illuminate\Http\Request;
use App\Models\Worker;
use App\Models\WorkerSallary;
use Validator;
class WorkerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $worker = Worker::where('user_id',auth()->user()->id)->get();
        return response()->json([ 'status'=>true, 'worker'=> $worker]);
    }


    public function store(RegisterWorkerRequest $request)
    {
        $validator = Validator::make($request->all(),[
            'name' => 'required|string',
            'mobile' => 'required',
            'sallary'=>'required',
            'person_id'=> 'required',
            'password' =>'required|min:8'
        ]);
        if($validator->fails()){
            return response()->json($validator->errors()->toJson(),400 );
        }
        $worker=Worker::create(array_merge(
            $validator->validate(),
            ['user_id' => auth()->user()->id ],
            ['password'=>bcrypt($request->password)]
        ));
        return response()->json($worker,201);
    }

/**
     * Show the form for editing the specified resource.
     */


    public function update(Request $request, string $id)
    {
        $worker = Worker::findOrFail($id);
        $worker->update([
            'project_id'=>$request->project_id,
            'name' => $request->name,
            'mobile' => $request->mobile,
            'sallary'=>$request->sallary,
            'person_id'=> $request->person_id,
        ]);
        return response()->json($worker,201);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $worker = Worker::findOrFail($id);
        $worker->update(['is_ative'=>0]);
        return response()->json([[ 'status'=>true, 'worker'=> $worker]]);
    }
}
