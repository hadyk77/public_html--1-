<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\MonthlyExpenses;
use Illuminate\Http\Request;

class ExpensesController extends Controller
{
       public function get($project_id)
    {
       $expenses = MonthlyExpenses::where('project_id',$project_id)
                                  ->where('user_id',auth()->user()->id)->get();
       return response()->json($expenses,201);
    }
    public function storeExpenses(Request $request,$project_id)
    {
       $Expenses= MonthlyExpenses::create([
            'project_id'=> $project_id,
            'name' =>$request->name,
            'sallary' => $request->	sallary,
            'user_id'=>auth()->user()->id,
        ]);
        return response()->json($Expenses,201);
    }
    public function updateExpenses(Request $request, int $id,$project_id)
    {
        $expenses = MonthlyExpenses::where('id',$id)->where('user_id',auth()->user()->id)->where('project_id',$project_id);
                $expenses->update([
            'sallary'=> $request->sallary,
            'name'=> $request->name,
        ]);
        return response()->json($expenses,201);

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
