<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProjectRequest;
use App\Models\Project;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Auth;
use SebastianBergmann\Comparator\ResourceComparator;
use Validator;
class ProjectController extends Controller
{
    public function index()
    {
        $project = Project::where('id' ,auth()->user()->id )-> orderBy('created_at','desc')->get();
        return response()->json($project);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProjectRequest $request)
    {

        $validator = Validator::make($request->all(),[
            'name' => 'required|string',
            'address' => 'required|string',
            'sallary' => 'required|integer',
            'worker_id' => 'required'
            ]);

        if($validator->fails()){
        return response()->json($validator->errors()->toJson(),400 );
        }
        if($request->worker_id == null){
        $worker_id = 0;
    }else{
    $worker_id = $request->worker_id;
    }
        $project= Project::create(
            array_merge( $validator->validate(),
                ['user_id'=>auth()->user()->id],
                ['worker_id'=> $worker_id ]
            ));
            return response()->json([
                'success'   => true,
                'message'=>'تم انشاء المشروع بنجاح',
                'project'=>$project,
            ]);


    }//end of store



    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, int $id)
    {
        $project = Project::find($id);
        $project->update($request->all());
        $project->save();
        return response()->json(['success'   => true]);
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $project = Project::findOrFail($id);
        $project->delete();
        return response()->json([
            'success'   => true,
            'project'=>$project,
        ]);

    }
}
