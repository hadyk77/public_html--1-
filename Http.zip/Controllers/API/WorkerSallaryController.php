<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\Worker;
use App\Models\WorkerSallary;
use Carbon\Carbon;
use Illuminate\Http\Request;

class WorkerSallaryController extends Controller
{
    public function get(int $project_id, $date)
    {
      $worker = Worker::where('project_id', '=', $project_id)->where('user_id', auth()->user()->id)->get();
foreach ($worker as $workers) {
    $date_old = WorkerSallary::where('project_id', '=', $project_id)
                              ->where('worker_id', $workers->id)
                              ->whereDate('date_at', $date)
                              ->count();

                            }

      foreach ($worker as $workers){
      $count= WorkerSallary::where('project_id', '=', $project_id)
                           ->where('worker_id',$workers->id)
                           ->whereDate('created_at', Carbon::today())
                           ->count();
    if( $count == 0){
    WorkerSallary::create([
            'worker_id'=> $workers->id ,
            'project_id' =>$workers->project_id,
            'sallary' => $workers->	sallary,
            'date_at'=>Carbon::today()
        ]);}
      }
    return response()->json($worker,201);
    }

    public function sallarydaily(Request $request, $project_id,$id)
    {
        $ids=Worker::where('project_id', '=', $project_id)
                   ->where('user_id', auth()->user()->id)
                   ->where('id',$id)->get('id');
        $sallarys=Worker::where('project_id', '=', $project_id)
                   ->where('user_id', auth()->user()->id)
                   ->where('id',$id)->sum('sallary');


        $sallary = WorkerSallary::whereIn('worker_id', $ids)
                                ->whereDate('created_at', Carbon::today());
        if($request->Presence == null){
            $presence = WorkerSallary::whereIn('worker_id', $ids)
                ->whereDate('created_at', Carbon::today())
                ->value('presence');
        }else{
            $presence = $request->Presence;
            $hours = 8;
        }

        if($request->add_hours == null){
            $add_sallary = WorkerSallary::whereIn('worker_id', $ids)
                ->whereDate('created_at', Carbon::today())
                ->value('add_sallary');
        }else{
            $hours = 8 + $request->add_hours;
            $add_sallary = ($sallarys /8) * $hours;
        }
        if($request->deduct_hours == null){
            $deduct_sallary = WorkerSallary::whereIn('worker_id', $ids)
                ->whereDate('created_at', Carbon::today())
                ->value('deduct_sallary');
        }else{
            $hours = 8 - $request->deduct_hours;
            $deduct_sallary = ($sallarys /8) * $hours;
        }


        $sallary->update([
            'Presence' => $presence,
            'hours' => $hours,
            'add_sallary'=> $add_sallary,
            'deduct_sallary'=> $deduct_sallary,
            'total_sallary'=> $sallarys + $request->add_sallary - $request->deduct_sallary
        ]);
        return response()->json('total_sallary = '.$sallarys + $request->add_sallary - $request->deduct_sallary,201);
    }



    public function sallarydailydetails($project_id,$id){
        $details=WorkerSallary::where('project_id', '=', $project_id)
                              ->where('worker_id',$id)->with('worker')->get();
        return response()->json($details,201);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
